CROSS-FREQUENCY PERFORMANCE LAB
Open index.html in Chrome or Edge. No Python or installation required.

Includes five interactive experiments:
1. Baseline vs optimized latency model.
2. Market-data traffic and queue behaviour.
3. Cross-frequency synchronization.
4. Incremental vs full-window statistics.
5. Bottleneck diagnostics and recommendations.

Academic note: this is a deterministic educational model, not a live exchange connection or measured production benchmark. Its outputs are simulated from assumptions. Do not present them as empirical results. Real proof requires baseline and optimized implementations measured on the same machine and workload, with repeated P50/P95/P99 and throughput results.

To share: email the ZIP or upload it to Google Drive and share the download link. For a live web URL, publish the extracted static folder using GitHub Pages or Netlify. Include this README when sharing.
